%% Interpolation: Newport, OR Coast Line Model Data
% Interpolate data from 3D to 2D grid
% Run with single monopole source, 3D

% Clear all variables and terms in the command window
clear all;  clc;

% Load recorded bathymetry for coastline
load bathy_contours_NETS
bathy = bathy_interp_cgrid; % Rename

% Plot bathymetry with line to indicate locations of some MHK WEC devices
pcolor(lonC,latC,bathy); shading flat; colorbar
caxis([0 50])
for iw=1:numel(WEC)
    l=line([WEC{iw}(:,1)],[WEC{iw}(:,2)]);
    l.Color='k';
    l.LineWidth=1.5;
end
colormap(flipud(parula(50)));

% Replicate array of longitude and latitude for re-plotting
lonmat=repmat(lonC,1,701)';
latmat=repmat(latC,1,401);

% Locate any value with a negative depth reading and set value to NaN
il = find(bathy<0);
bathy(il) = NaN;

% Plot bathymetry showing only the areas with a positive water depth with
% locations of WECs incidated by a line & format
figure
pcolor(lonmat,latmat,bathy); shading flat; colorbar;
caxis([0 50]);
colormap(flipud(parula(50)));
for iw=1:numel(WEC)
    l=line([WEC{iw}(:,1)],[WEC{iw}(:,2)]);
    l.Color='k';
    l.LineWidth=1.5;    
end
% Location of WECS for reference
line([lonC(41);lonC(241)],[latC(398) latC(398)]);

% Select section of interest: Longitude
slicexz = bathy(141,:);
% Find all values of NaN & remove them from the array of depth values for
% bathymetry
NaNi = find(isnan(slicexz));
slicexz(NaNi) = [];

% Select section of interest: Latitude
sliceyz = bathy(:,92);

% By selecting a longigude and latitude, that selects a 2D cross section of
% bathymetric data, call this a slice. Indicates all data propagating out
% from a point (lat,long) in two directions, xz or yz

% Convert longitude values to m
n = 79434.3163923549; %m per degree; Lat = 44.57 degrees
Ri = (lonC - lonC(1,1));
i = Ri(2,1)-Ri(1,1);
Rangei = n.*Ri;
Rangei(NaNi) = [];
slicexz = [slicexz 0];
slicexz = fliplr(slicexz);
% Select converted data from slice for all positive, non-zero values; call
% it a Range
Rangei = [Rangei; i*n+Rangei(find(Rangei,1,'last'),1)];

% Convert latatude values to m
m = 111123.34314454331; %m per degree; Lat = 44.57 degrees
Rj = (latC - latC(1,1));
j = Rj(2,1)-Rj(1,1);
% Rename converted data from slice for all positive, non-zero values; call
% it a Range
Rangej = m.*Rj;
sliceyz = flipud(sliceyz);

% Save slices in mat file
save('Newport_slice.mat','slicexz','Rangei','sliceyz','Rangej');

% Plot selected 2D slice for bathymetry in example model & format
% Range slice extends from the coast line outward
figure
plot(Rangei,slicexz)
set(gca,'Ydir','reverse')
set(gca,'Xdir','reverse')

%% Domain & Grid Set Up

% Simulation name
% Define a simulation name for the matlab file
simname = 'Interplinear';

% Define a simulation name for the matlab file
x=0:1.5:7500;
y=-30:1.5:30;
z=-6:1.5:90;

% Define the simulation run time & dt
t=0:0.0002:8;

% Interpolate data onto new spacing
% Note that collected bathymetry data is on a coarser grid than required
% for the model, so we must interpolated onto the defined grid
% => OPTIONS FOR METHOD = linear, nearest, pchip
sliceint = interp1(Rangei,slicexz,x,'linear');

% Assign velocity & density values to cross-section

% Predefine the size of array necessary for vp & rho; populate with 1s
vp = ones(length(x),length(y),length(z));
rho = ones(length(x),length(y),length(z));

% Populate vp & rho arrays with constant values based on location in domain
% Since there is only two layers (water column & soil), assign values
% based on depth. For a value of depth, assign one value or another if you
% are above z = zu, where zu is the location of the bottom of the water
% column, or elsewhere.
for i=1:length(x)
    for j=1:length(z)
        zu(i)=sliceint(1,i);
        if z(j)>zu(i)
        vp(i,:,j)=1800;
        rho(i,:,j)=1800;
        else
        vp(i,:,j)=1500;
        rho(i,:,j)=1000;
        end
    end
end

% Source
% Note: the source amplitude has to do with the double derivative of the
% pressure. It can be changed to match whatever source function you have
% interest in. Or, you can import a text file, overlay functions, etc.
sf=100;            % Source max Frequency, (Hz)
sa=1;              % Source Amplitude, (Pa)
sxyz=[3600 0 20];  % Source Location [x y z] (m)

c = 1500; % Sound speed at source location

% Define sound source profile
A = sa*c^2/(pi()*sf^2);  % Integration terms and scaling factor (N)
amp(1:length(t)) = A*(1-cos(2*pi*sf*t));    % Continuous source function (Pa

%Write Source txt file for Paracousti

% Define an array, T
T = table(t',amp');
% Write the data to a table & output as a text file with comma deliminated
% formating
writetable(T,'sourceinterp.txt','writeVariablenames',0,'delimiter','\t');

% Define source command promps; store as a text string to call later
% %d references the data following with sa previously defined as an
% amplitude scaler equal to 1
source=sprintf('-Sw sourceinterp.txt -Se %d %d %d %d',sxyz(1,1),sxyz(1,2),sxyz(1,3),sa);

% Define and store boundary conditions command promps for a pressure-free surface (-bF) &
% CPML condition on all sides of the model domain (-bpc6)
boundary = sprintf('-bF -bpc6 10 1e-6 314 1 10 1e-6 314 1 10 1e-6 314 1 10 1e-6 314 1 4 1e-6 314 1 10 1e-6 314 1');

% Recievers and Output File Write Set Up

% Create a grid of recievers over locations in the model domain with
% respect to acutal locations and not counter variables (-Rg);
% define output location and file type for recievers (-Ro);
% define a total number of 500 slices to be stored in the XZ plane
% at y = 0 (-En); define output locaiton of the slice files
% Store allof the command promps as a string
reciever=sprintf('-Rg Pressure 5:100:7405 0:0 10:10:80');
filewrite=sprintf('-Ro %s.trace.cdf -En 500 Pressure XZ 0 -Eo %s.slice.cdf',simname,simname);

% Check dx and dt values
% Calcuate minimum necessary dx and dt to compare against assigned values
% above
dxr=min(vp)/sf/10;
dtr=dxr/max(vp)/2.04;

%% Write Paracousti Input File
% Write cdf input file for Paracousti labeling it 'interplinear' with the
% defined domain x, y, and z, run time t, and arrays vp and rho
writeSgfdModel('interplinear.cdf',x,y,z,t,'vp',vp,'rho',rho)

%% Execute Paracousti

% Output all of the necessary commands to run Paracousti into a text file
% so that it may be easily stored and referenced later. The entire string
% still needs to be copied into a command window with all programs required
% (as defined by the user manual) are available. 
% The text file will be named with the same value as specified for the
% simname.
% Outputs the batch file to run Paracousti in Linux

command=sprintf('mpirun -np 4 ParAcousti_RHEL6 interppchip.cdf -p 1 1 3 %s %s %s %s',boundary,source,reciever,filewrite);
fileID=fopen(sprintf('sbatch%s.txt',simname),'w');
fprintf(fileID,batch);
fprintf(fileID,command);
fclose(fileID);

%% Post Process: Pressure Trace

% Call the trace output file and read all trace data collected at a
% particular location
% Traces files are organized in an i,j,k counting scheme
% For example, point 250 would be located at [x,y,z] = [2940 0 40]
Pt=ncread('interplinear.trace.cdf','receiverData',[1 250],[inf 1]);

% Calcuate the Sound Pressure Level with reference pressure 1 microPa
SPLtrace = 20.*log10(Pt./1e-6); % (dB)

% Plot & format the SPL data 
figure
plot(t,SPLtrace)
xlabel('Range (m)','fontsize',16)
ylabel('SPL (dB)','fontsize',16)
title('Sound Pressure Level (dB) for Newport, OR','fontsize',14)

%% Post Process: Pressure Slice 
clear P % If you run this a bunch of times, it is faster to clear and rewrite than over write

% Determine the size of the slice file in terms of how many slices it
% contains; this is important if the model is large enough to generate
% multiple slice files
slice_info = ncinfo('interplinear.slice.cdf');
% Create and output a data string with requested data
[~,~,~,slice_length] = slice_info.Dimensions.Length;

% Call the slices from the last half of the model run (after the sound wave
% has reached the boundaries and the model is now at steady state)
% Squeeze the array size to overlay all of the slice data called and
% prodice 1 slice that may be plotted for the entire period of time
% If you want to only call 1 slice, change the value of i to a singular
% counter variable
for i=250:500
    P(:,:,i-249)=squeeze(ncread('interplinear.slice.cdf','xzPressure',[1 1 i],[inf inf 1]));
end

% Calculate the root mean squared pressure (Pa)
Prms=sqrt(mean(P.^2,3));

% Calcuate the sound pressure level (dB) with reference pressure 1 microPa
SPL=20.*log10(Prms./1e-6);

% Plot SPL data as a 2D image in the XZ plane & format
figure
imagesc(x,z,SPL')
xlabel('Range (m)','fontsize',16)
ylabel('Depth (m)','fontsize',16)
title('Sound Pressure Level (dB) for Newport, OR','fontsize',14)
c= colorbar;
c.Label.String = 'dB re 1 \muPa';
refline(0,100);
 
% Plot SPL data for depth of 20 m only & format (depth of source)
figure
plot(x,SPL(:,find(z>=19,1,'first')))
xlabel('Range (m)')
ylabel('Sound Pressure Level (dB)')
title('Sound Pressure Level (dB) for Newport, OR')
legend('RD=20m')