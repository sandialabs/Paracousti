%% Interpolation: Newport Data
% Interpolate data from 3D to 2D grid
% Run with single monopole source, 2D

% 6/21/2017
clear all, clc;

% Bring in bathymetry file; all collected data points and associated data
% which load as MATLAB variables
load bathy_contours_NETS

% Rename data for only the bathymetric data points
bathy = bathy_interp_cgrid;

% Plot given bathy data
% Note that this particuar data set had several Wave Energy Converters
% (WECs)located within; a line has been added to indicate their location
pcolor(lonC,latC,bathy); shading flat; colorbar
caxis([0 50])
for iw=1:numel(WEC)
    l=line([WEC{iw}(:,1)],[WEC{iw}(:,2)]);
    l.Color='k';
    l.LineWidth=1.5;
end
colormap(flipud(parula(50)));

% Reprint some data points for visualization
lonmat=repmat(lonC,1,701)';
latmat=repmat(latC,1,401);

% Locate all data points where the depth is less then zero where water
% depth is anything greater than zero; change data type to NaN at those 
% locations. We need all bathy points which represent water only. NaN
% causes those data points to be generally ignored
il = find(bathy<0);
bathy(il) = NaN;

%Plot modified data set, again with line to represent the WEC locations.
%The line is not necessary for this tutorial, just interesting
figure
pcolor(lonmat,latmat,bathy); shading flat; colorbar;
caxis([0 50]);
colormap(flipud(parula(50)));
for iw=1:numel(WEC)
    l=line([WEC{iw}(:,1)],[WEC{iw}(:,2)]);
    l.Color='k';
    l.LineWidth=1.5;    
end

% Location of WECS for reference
line([lonC(41);lonC(241)],[latC(398) latC(398)]);

% Select section of interest: Longitude
% Data is on a long/lat grid; loading the bathy_contours_NETS.mat loaded
% several matricies which contain the associated latitude and longitude
% locations. Each point index references the point index for the bathy
% file. So, you can select any cross-section that you would like in either
% the latitudinal or longitudinal directions
slicexz = bathy(141,:);

% Take all data points already set as NaN and remove them from the matrix
NaNi = find(isnan(slicexz));
slicexz(NaNi) = [];

% Select section of interest: Latatude
sliceyz = bathy(:,92);

% Convert longitude values to m
n = 79434.3163923549; %m per degree; Lat = 44.57 degrees
Ri = (lonC - lonC(1,1));
i = Ri(2,1)-Ri(1,1);
Rangei = n.*Ri;
Rangei(NaNi) = [];
slicexz = [slicexz 0];
slicexz = fliplr(slicexz);
Rangei = [Rangei; i*n+Rangei(find(Rangei,1,'last'),1)];

% Convert latatude values to m
m = 111123.34314454331; %m per degree; Lat = 44.57 degrees
Rj = (latC - latC(1,1));
j = Rj(2,1)-Rj(1,1);
Rangej = m.*Rj;
sliceyz = flipud(sliceyz);

% Save slices in mat file
save('Newport_slice.mat','slicexz','Rangei','sliceyz','Rangej');

figure
plot(Rangei,slicexz)
set(gca,'Ydir','reverse')
set(gca,'Xdir','reverse')

%% Domain & Grid Set Up

% Simulation name
simname = 'Newport'

% Grid/Step size
x=0:1.5:7500;
y=-30:1.5:30;
z=-6:1.5:90;
t=0:0.0002:8;

% Interpolate data onto new spacing
% => OPTIONS FOR METHOD = linear, nearest, pchip
sliceint = interp1(Rangei,slicexz,x,'pchip');

% Assign velocity & density values to cross-section
vp = ones(length(x),length(y),length(z));
rho = ones(length(x),length(y),length(z));

for i=1:length(x)
    for j=1:length(z)
        zu(i)=sliceint(1,i);
        if z(j)>zu(i)
        vp(i,:,j)=1800;
        rho(i,:,j)=1800;
        else
        vp(i,:,j)=1500;
        rho(i,:,j)=1000;
        end
    end
end

% Source
% Note: the source amplitude has to do with the double derivative of the
% pressure. It can be changed to match whatever source function you have
% interest in. Or, you can import a text file, overlay functions, etc.
sf=100;            % Source max Frequency, Hz
sa=1;             % Source Amplitude, Pa
sxyz=[3600 0 20];    % Source Location [x y z]

c = 1500; % Sound speed at source location
A = sa*c^2/(pi()*sf^2); % Newtons
amp(1:length(t)) = A*(1-cos(2*pi*sf*t));    % Source profile, Pa

%Write Source txt file for Paracousti
T = table(t',amp');
writetable(T,'newport.txt','writeVariablenames',0,'delimiter','\t');

% Call for source and location of source
source=sprintf('-Sw newport.txt -Se %d %d %d %d',sxyz(1,1),sxyz(1,2),sxyz(1,3),sa);
% Call for boundary conditions
boundary = sprintf('-bF -bpc6 10 1e-6 62 1 10 1e-6 62 1 10 1e-6 62 1 10 1e-6 62 1 4 1e-6 62 1 10 1e-6 62 1');

% Recievers and Output File Write Set Up
reciever=sprintf('-Rg Pressure 5:100:7405 0:0 10:10:80');
filewrite=sprintf('-Ro %s.trace.cdf -En 500 Pressure XZ 0 -Eo %s.slice.cdf',simname,simname);

% Check dx and dt values
dxr=min(vp)/sf/10;
dtr=dxr/max(vp)/2.04;

%% Write Paracousti Input File
writeSgfdModel('newport.cdf',x,y,z,t,'vp',vp,'rho',rho)

%% Execute Paracousti

% Outputs the batch file to run Paracousti in Linux
% This batch file is setup to run on the MSU computing cluter (Hyalite)
command=sprintf('mpirun -np 13 /home/erin.hafla/bin/ParAcousti newport.cdf -p 1 3 4 %s %s %s %s',boundary,source,reciever,filewrite);
batch=sprintf('#!/bin/bash\n#SBATCH -J %s\n#SBATCH --time=24:00:00\n#SBATCH --nodes=1\n#SBATCH --ntasks=13\n#SBATCH --mail-type=ALL\n#SBATCH --mail-user=erinhafla@gmail.com\n#SBATCH -p priority\n module purge\n module load shared hyalite netCDF/4.4.0-foss-2016a\n',simname);
fileID=fopen(sprintf('sbatch%s.txt',simname),'w');
fprintf(fileID,batch);
fprintf(fileID,command);
fclose(fileID);