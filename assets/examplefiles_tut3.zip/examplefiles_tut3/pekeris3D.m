%% Pekeris Waveguide

% Clear all variables and terms in the command window
clear, clc

% Domain & Grid Set Up

% Define a simulation name for the matlab file
simname = 'Pekeris3D';

% Define the size of the domain & step size
x=-160:1:4000;
y=-160:1:160;
z=-2:1:200;

% Define the simulation run time & dt
t=0:0.0002:6;

% Sound Speed & Density

% Predefine the size of array necessary for vp & rho; populate with 1s
vp = ones(length(x),length(y),length(z));
rho = ones(length(x),length(y),length(z));

% Populate vp & rho arrays with constant values based on location in domain
% Since there is only two layers separated with a flat layer, assign values
% based on depth
% for a value of depth, assign one value or another if you are above z =
% 100 or below and/or equal to 100 m
for i=1:length(z)
    if z(i)<=100
        vp(:,:,i)=1500;
        rho(:,:,i)=1000;
    else
        vp(:,:,i)=1800;
        rho(:,:,i)=1800;
    end
end

% Source Parameters
sf=20;            % Source max Frequency (Hz)
sa=1;             % Source Amplitude (Pa)
sxyz=[0 0 36];    % Source Location [x y z] (m)

c = 1500; % Sound speed at source location (m/s)

% Define sound source profile
A = sa*c^2/(pi()*sf^2); % Integration terms and scaling factor (N)
amp(1:length(t)) = A*(1-cos(2*pi*sf*t));    % Continuous source function (Pa)

%Write Source text file for paracousti

% Define a file ID
fileID = fopen('sourcepekeris.txt','w');

% Define what is included in the text file
sr=[t;amp];

% Print text file with data set as a row; data does not need to be comma
% deliminated, it just makes it easier to visualize
fprintf(fileID,'%12.8f %12.8f\n',sr);
fclose(fileID); % Close file

% Define source command promps; store as a text string to call later
% %d references the data following with sa previously defined as an
% amplitude scaler equal to 1
source=sprintf('-Sw sourcepekeris.txt -Se %d %d %d %d',sxyz(1,1),sxyz(1,2),sxyz(1,3),sa);

% Define and store boundary conditions command promps for a pressure-free surface (-bF) &
% CPML condition on all sides of the model domain (-bpc6)
boundary = sprintf('-bF -bpc6 10 1e-6 62 1 10 1e-6 62 1 10 1e-6 62 1 10 1e-6 62 1 2 1 62 1 10 1e-6 62 1');

% Recievers and Output File Write Set Up

% Create a grid of recievers over locations in the model domain with
% respect to acutal locations and not counter variables (-Rg);
% define output location and file type for recievers (-Ro);
% define a total number of 1000 slices to be stored in the XZ plane
% at y = 0 (-En); define output locaiton of the slice files
% Store allof the command promps as a string
reciever=sprintf('-Rg Pressure 5:100:3905 0:0 10:5:200');
filewrite=sprintf('-Ro pekeris3D.trace.cdf -En 1000 Pressure XZ 0 -Eo pekeris3D.slice.cdf');

% Check dx and dt values
% Calcuate minimum necessary dx and dt to compare against assigned values
% above
dxr=min(vp)./sf./10;
dtr=dxr./max(vp)./2.04;

%% Write Paracousti Input File
% Write cdf input file for Paracousti labeling it 'pekeris3D' with the
% defined domain x, y, and z, run time t, and arrays vp and rho
writeSgfdModel('pekeris3D.cdf',x,y,z,t,'vp',vp,'rho',rho)

%% Execute Paracousti

% Output all of the necessary commands to run Paracousti into a text file
% so that it may be easily stored and referenced later. The entire string
% still needs to be copied into a command window with all programs required
% (as defined by the user manual) are available. 
% The text file will be named with the same value as specified for the
% simname.
% Outputs the batch file to run Paracousti in Linux
command=sprintf('mpirun -np 4 ParAcousti_RHEL6 pekeris3D.cdf -p 1 1 3 %s %s %s %s',boundary,source,reciever,filewrite);
fileID=fopen(sprintf('sbatch%s.txt',simname),'w');
fprintf(fileID,command);
fclose(fileID);

%% Post Process: Pressure Trace

% Call the trace output file and read all trace data collected at a
% particular location
% Traces files are organized in an i,j,k counting scheme
% For example, point 250 would be located at [x,y,z] = [1605 0 40]
Pt=ncread('pekeris3D.trace.cdf','receiverData',[1 250],[inf 1]);

% Calcuate the Sound Pressure Level with reference pressure 1 microPa
SPLtrace = 20.*log10(Pt./1e-6); % (dB)

% Plot & format the SPL data 
figure
plot(t,SPLtrace)
xlabel('Range (m)','fontsize',16)
ylabel('SPL (dB)','fontsize',16)
title('Sound Pressure Level (dB) of Two Layered Waveguide','fontsize',14)

%% Post Process: Pressure Slice 
clear P % If you run this a bunch of times, it is faster to clear and rewrite than over write

% Determine the size of the slice file in terms of how many slices it
% contains; this is important if the model is large enough to generate
% multiple slice files
slice_info = ncinfo('pekeris3D.slice.cdf');
% Create and output a data string with requested data
[~,~,~,slice_length] = slice_info.Dimensions.Length;

% Call the slices from the last half of the model run (after the sound wave
% has reached the boundaries and the model is now at steady state)
% Squeeze the array size to overlay all of the slice data called and
% prodice 1 slice that may be plotted for the entire period of time
% If you want to only call 1 slice, change the value of i to a singular
% counter variable
for i=500:1000
    P(:,:,i-499)=squeeze(ncread('pekeris3D.slice.cdf','xzPressure',[1 1 i],[inf inf 1]));
end

% Calculate the root mean squared pressure (Pa)
Prms=sqrt(mean(P.^2,3));

% Calcuate the sound pressure level (dB) with reference pressure 1 microPa
SPL=20.*log10(Prms./1e-6);

% Plot SPL data as a 2D image in the XZ plane & format
figure
imagesc(x,z,SPL')
xlabel('Range (m)','fontsize',16)
ylabel('Depth (m)','fontsize',16)
title('Sound Pressure Level (dB) of Two Layered Waveguide','fontsize',14)
axis([0 3000 2 200])
c= colorbar;
c.Label.String = 'dB re 1 \muPa';
refline(0,100);
 
% Plot SPL data for depth of 36 m only & format
figure
plot(x,SPL(:,find(z>=35,1,'first')))
xlabel('Range (m)')
ylabel('Sound Pressure Level (dB)')
title('Sound Pressure Level (dB) of Two Layered Waveguide')
legend('RD=36m')


