%% Pekeris Waveguide
% Post Processing Tutorial File

% Clear all variables and terms in the command window
clear, clc

% Find and open the file tree in MATLAB with the Pekeris Slice and Trace
% output files that were generated from Tutorial 1
    % pekeris3D.slice.cdf
    % pekeris3D.trace.cdf
    
% Redefine the size of the domain & step size
x=-160:1:4000;
y=-160:1:160;
z=-2:1:200;

% Redefine the simulation run time & dt
t=0:0.0002:6;

% Post Process: Pressure Slice 
% Determine the size of the slice file in terms of how many slices it
% contains; this is important if the model is large enough to generate
% multiple slice files
slice_info = ncinfo('pekeris3D.slice.cdf');
% Create and output a data string with requested data
[~,~,~,slice_length] = slice_info.Dimensions.Length;

% Call the slices from the last half of the model run (after the sound wave
% has reached the boundaries and the model is now at steady state)
% Squeeze the array size to overlay all of the slice data called and
% prodice 1 slice that may be plotted for the entire period of time
% If you want to only call 1 slice, change the value of i to a singular
% counter variable
for i=500:1000
    P(:,:,i-499)=squeeze(ncread('pekeris3D.slice.cdf','xzPressure',[1 1 i],[inf inf 1]));
end

% Calculate the root mean squared pressure (Pa)
Prms=sqrt(mean(P.^2,3));

% Calcuate the sound pressure level (dB) with reference pressure 1 microPa
SPL=20.*log10(Prms./1e-6);

% Plot SPL data as a 2D image in the XZ plane & format
figure
imagesc(x,z,SPL')
xlabel('Range (m)','fontsize',14)
ylabel('Depth (m)','fontsize',14)
title('Sound Pressure Level (dB) of Two Layered Waveguide','fontsize',14)
axis([0 3000 2 200])
c= colorbar;
c.Label.String = 'dB re 1 \muPa';
refline(0,100);
 
% Plot SPL data for depth of 36 m only & format
figure
plot(x,SPL(:,find(z>=35,1,'first')))
xlabel('Range (m)','fontsize',14)
ylabel('Sound Pressure Level (dB)','fontsize',14)
title('Sound Pressure Level (dB) of Two Layered Waveguide')
legend('RD=36m')

% Average Pressure slice data over a water depth
% Bottom depth = 100 m

% Assign counter integer for bottom location in z matrix
zb = find(z==100);
for i = 1:length(x)
    Pavg(i) = mean(Prms(i,3:zb));
    % Average only over the water column depth; discount the boundary zone
end
SPLavg = 20.*log10(Pavg./1e-6);

figure
plot(x,SPLavg)
xlabel('Range (m)','fontsize',14)
ylabel ('Depth Averaged Sound Pressure Level (dB)','fontsize',14)
title('Sound Pressure Level (dB re 1 \muPa) of a Two Layered Waveguide')

% Post Process: Traces

% Call the trace output file and read all trace data collected at a
% particular location
% Traces files are organized in an i,j,k counting scheme
% For example, point 250 would be located at [x,y,z] = [1605 0 40]
Pt=ncread('pekeris3D.trace.cdf','receiverData',[1 250],[inf 1]);

% Calcuate the Sound Pressure Level with reference pressure 1 microPa
SPLtrace = 20.*log10(Pt./1e-6); % (dB)

% Plot & format the SPL data 
figure
plot(t,SPLtrace)
xlabel('Range (m)','fontsize',14)
ylabel('SPL (dB)','fontsize',14)
title('Sound Pressure Level (dB) of Two Layered Waveguide','fontsize',14)

% Plot each pressure trace one at a time over top of one another to check
% data; to exit type 'Ctrl C'
% This is useful if you wish to cylce through all the trace data with
% minimal formatting; output is in Pa
% The total number of trace files is 1482
% Any singular key stroke is required to plot the next trace file

for i = 1:1482
    Pt = ncread('pekeris3D.trace.cdf','receiverData',[1 i],[inf 1]);
    plot(Pt)
    xlabel('Range (m)','fontsize',14)
    ylabel('Pressure data (Pa)','fontsize',14)
    title(['Pressure data; Trace = ',num2str(i),])
    pause
end







