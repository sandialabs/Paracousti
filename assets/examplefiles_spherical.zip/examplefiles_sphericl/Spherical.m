%% Spherical Spreading Analytic Example

% Clear all variables and terms in the command window
clear, clc

% Domain & Grid Set Up

% Define a simulation name for the matlab file
simname = 'Spherical';

% Define the size of the domain & step size
x=-60:5:1500;
y=-100:5:100;
z=-50:5:150;

% Define the simulation run time & dt
t=0:0.0015:1;

% Predefine the size of array necessary for vp & rho; populate with 1s
vp = ones(length(x),length(y),length(z));
rho = ones(length(x),length(y),length(z));

% Populate vp & rho arrays with constant values based on location in domain
% Since there is only one layer, vp & rho are constant
vp(:,:,:)=1500;
rho(:,:,:)=1000;

% Source Parameters
sf=20;            % Source max Frequency (Hz)
sa=10;             % Source Amplitude (Pa)
sxyz=[0 0 10];    % Source Location [x y z] (m)

% Define sound source profile: Singular Gaussian pulse
amp=normrnd(8,0.0015,length(t));

%Write Source txt file for Paracousti

% Define an array, T
T = table(t',amp');
% Write the data to a table & output as a text file with comma deliminated
% formating
writetable(T,'spherical.txt','writeVariablenames',0,'delimiter','\t')

% Define source command promps; store as a text string to call later
% %d references the data following with sa previously defined as an
% amplitude scaler equal to 1
source=sprintf('-Sw spherical.txt -Se %d %d %d %d',sxyz(1),sxyz(2),sxyz(3),sa);

% Define and store boundary conditions command promps for a system in only
% a water column % CPML condition on all sides of the model domain
% (-bpc) with constant properties for all boundaries
boundary = sprintf('-bpc 10 1e-6 62 1');

% Recievers and Output File Write Set Up

% Create a grid of recievers over locations in the model domain with
% respect to acutal locations and not counter variables (-Rg);
% define output location and file type for recievers (-Ro);
% define a total number of 100 slices to be stored in the XZ plane
% at y = 0 (-En); define output locaiton of the slice files
% Store allof the command promps as a string
reciever=sprintf('-Rg Pressure 500:500 0:0 5:5:140');
filewrite=sprintf('-Ro Spherical.trace.cdf -En 100 Pressure XZ 0 -Eo Spherical.slice.cdf');

% Check dx and dt values
% Calcuate minimum necessary dx and dt to compare against assigned values
% above
dxr=min(vp)./sf./10;
dtr=dxr./max(vp)./2.04;

%% Write Paracousti Input File
% Write cdf input file for Paracousti labeling it 'pekeris3D' with the
% defined domain x, y, and z, run time t, and arrays vp and rho
writeSgfdModel('Spherical.cdf',x,y,z,t,'vp',vp,'rho',rho)

clear vp rho T
%% Execute Paracousti

% Output all of the necessary commands to run Paracousti into a text file
% so that it may be easily stored and referenced later. The entire string
% still needs to be copied into a command window with all programs required
% (as defined by the user manual) are available. 
% The text file will be named with the same value as specified for the
% simname.
% Outputs the batch file to run Paracousti in Linux
command=sprintf('mpirun -np 4 ParAcousti_RHEL6 Spherical.cdf -p 1 1 3 %s %s %s %s',boundary,source,reciever,filewrite);
fileID=fopen(sprintf('sbatch%s.txt',simname),'w');
fprintf(fileID,command);
fclose(fileID);

%% Post Process: Pressure Trace

% Call the trace output file and read all trace data collected at a
% particular location
% Traces files are organized in an i,j,k counting scheme
% For example, point 10 would be located at [x,y,z] = [500 0 50]
Pt=ncread('Spherical.trace.cdf','receiverData',[1 10],[inf 1]);

% Calcuate the Sound Pressure Level with reference pressure 1 microPa
SPLtrace = 20.*log10(Pt./1e-6); % (dB)

% Plot & format the SPL data 
figure
plot(t,SPLtrace)
xlabel('Range (m)','fontsize',16)
ylabel('SPL (dB)','fontsize',16)
title('Sound Pressure Level (dB) for Spherical Example','fontsize',14)%% Post Processing

%% Post Process: Pressure 
clear P % If you run this a bunch of times, it is faster to clear and rewrite than over write

% Determine the size of the slice file in terms of how many slices it
% contains; this is important if the model is large enough to generate
% multiple slice files
slice_info = ncinfo('Spherical.slice.cdf');
% Create and output a data string with requested data
[~,~,~,slice_length] = slice_info.Dimensions.Length;

% Call the slices from the entire model run 
% Squeeze the array size to overlay all of the slice data called and
% prodice 1 slice that may be plotted for the entire period of time
% If you want to only call 1 slice, change the value of i to a singular
% counter variable
for i=1:100
    P(:,:,i)=squeeze(ncread('Spherical.slice.cdf','xzPressure',[1 1 i],[inf inf 1]));
end

% Calculate the root mean squared pressure (Pa)
Prms=sqrt(mean(P.^2,3));

% Calcuate the sound pressure level (dB) with reference pressure 1 microPa
SPL=20.*log10(Prms./1e-6);

% Plot SPL data as a 2D image in the XZ plane & format
figure
imagesc(x,z,SPL')
xlabel('Range (m)','fontsize',16)
ylabel('Depth (m)','fontsize',16)
title('Sound Pressure Level (dB) for Spherical Example','fontsize',14)
c= colorbar;
c.Label.String = 'dB re 1 \muPa';

%% Compare against Analytical Solution
% Calculate Analytical Solution for a spherical case
tg=10*gradient(gradient(amp',0.0015),0.0015);
for i=1:length(t)
     for k=1:length(z)
            delay(k)=sqrt(500^2+(z(k)-10)^2)/1500;
            tt(i,k)=(t(i)-delay(k));
            
            if t(i)>=delay(k)
                aa(i,k)=tg(round(tt(i,k)/0.0015)+1);
                pr(i,k)=aa(i,k)/(4*pi*1500^2*sqrt(500^2+(z(k)-10)^2));
            else
                pr(i,k)=0;
            end
     end
end
 
% Plot trace data against analytical solution
figure
for i=1:25
plot(t,pr(:,i+11),t,ncread('Spherical.trace.cdf','receiverData',[1 i],[inf 1]),'+')
legend('Analytic','Paracousti')
xlabel('Time (s)')
ylabel('Pressure (Pa)')
end








